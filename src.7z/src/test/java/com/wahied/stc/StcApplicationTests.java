package com.wahied.stc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StcApplicationTests {

	@Test
	void contextLoads() {
	}

}
