package com.wahied.stc.repository;

import com.wahied.stc.entity.Permissions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PermissionsRepo extends JpaRepository<Permissions,Long> {

    Permissions findAllByEmail(String email);
}
