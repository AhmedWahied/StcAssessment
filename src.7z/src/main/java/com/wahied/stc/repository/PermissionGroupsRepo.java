package com.wahied.stc.repository;

import com.wahied.stc.entity.PermissionGroups;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PermissionGroupsRepo extends JpaRepository<PermissionGroups,Long> {
}
