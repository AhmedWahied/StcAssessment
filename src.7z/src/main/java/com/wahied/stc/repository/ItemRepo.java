package com.wahied.stc.repository;

import com.wahied.stc.entity.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemRepo extends JpaRepository<Item,Long> {
    Item findAllByName(String name);
    List<Item> findAllByType(String type);

}
